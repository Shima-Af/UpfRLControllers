# wcnc_paper_results — manifest

Result files for the WCNC 2027 revision of *"A Measurement-Grounded Digital Twin for
Evaluating Cooperative MARL in Energy-Aware 5G UPF Orchestration"*.

**How this archive was assembled.**
- It uses existing results only. No controller was trained or retuned, and the physical testbed was not used.
- Everything is a copy of files generated on 2026-09-14 in `reports/wcnc2027-shared-policy-ablation/` and `reports/wcnc2027-calibration-robustness/` (repository `UpfRLControllers`, HEAD 71a1b2f plus untracked study code).
- One figure was missing and was regenerated from saved result files only: `calibration_robustness/figures/fig4_difference_from_pinned_S2.pdf`, drawn by `s05_figures.py` from `evaluation_results.csv` and `fixed_action_replay.csv`.
- No checkpoints, surrogate bundles, rollouts, logs, environments, profiling data or vendored code are included.

All values come from a **surrogate digital twin** calibrated on profiling data. They are not
measurements of a live or deployed network.

---

## 1. Contents

```
MANIFEST.md
ablation/                                   centralized-PPO seed completion + Shared-PPO ablation
  all_seed_metrics.csv                      per run (per seed), fleet and per cluster
  aggregate_metrics.csv                     across seeds, per controller
  paired_comparisons.csv                    seed-matched paired differences
  per_cluster_summary.csv                   across seeds, per controller x cluster
  per_cluster_contrasts.csv                 per-cluster paired differences across seeds
  figures/fig_seed_rewards.pdf
  figures/fig_paired_differences.pdf
  figures/fig_energy_qos.pdf
  figures/fig_per_cluster.pdf
  figures/fig_reward_components.pdf
calibration_robustness/                     zero-shot evaluation in 20 alternative surrogate calibrations
  evaluation_results.csv                    per checkpoint x world, Experiment A
  controller_world_summary.csv              across seeds, per set x controller x world x experiment
  rank_stability.csv                        per set x experiment x world: rankings and key differences
  fold_summary.csv                          best / median / worst fold per protocol
  uncertainty_decomposition.csv             seed vs calibration uncertainty
  decision_boundary_summary.csv             50–600 Mbps decision analysis, across seeds
  figures/fig1_calibration_robustness_S2.pdf
  figures/fig2_energy_qos_scatter_S2.pdf
  figures/fig3_ranking_heatmap_S2.pdf
  figures/fig4_difference_from_pinned_S2.pdf
  figures/fig5_decision_trace.pdf          (uses set S1, see §3.3)
```

## 2. Seeds

The eight training seeds are **1, 7, 13, 23, 42, 64, 77, 99**.

- **Same-code set.** MAPPO, Shared-PPO, IPPO and centralized PPO use all eight, and a given seed denotes the same training seed for every controller. Paired differences are formed between runs with the same seed.
- **Exceptions.** In the calibration study's sets S1 and S3, centralized PPO uses 4 seeds (7, 13, 42, 99). Some legacy sets in the ablation CSVs have fewer seeds; the `seeds` column lists them.
- **Baselines.** Hysteresis and always-DPDK (and always-USR in the calibration CSVs) are deterministic and appear once, with `seed = 0`.

## 3. Controller cohorts

### 3.1 Same-code retrained set (the paper cohort)

- **Checkpoints.** `experiments/wcnc2027_ablation/{mappo,shared_ppo,ippo,central}_seed<N>/`, retrained 2026-09-14 with identical code, digital twin v0.4.0 and the current reward. Each has 200,000 environment steps and a best-of-validation checkpoint.
- **Name in the ablation CSVs:** `group = primary`.
- **Name in the calibration study:** set **S2** (`in_S2 = True`, `set = "S2"`).
- **Controllers.**
  - MAPPO: shared actor, centralized critic.
  - Shared-PPO: shared actor, shared local critic (the ablation).
  - IPPO: 10 independent single-site PPOs.
  - Centralized PPO: one PPO with a joint action.

### 3.2 Baselines (both studies)

- **Hysteresis.** Fixed thresholds as published: t_up 81 Mbps, t_down 31 Mbps (band b = 50 Mbps), cooldown 1 step.
  - Name in the ablation CSVs: `Hysteresis (b=50 Mbps)`.
  - Name in the calibration CSVs: `Hysteresis (fixed)`.
- **Always-DPDK.** Static policy that always uses the DPDK UPF.
- **Always-USR (supplementary).** Only in the calibration CSVs. It was not part of the manuscript's evaluation and is excluded from every ranking.

### 3.3 Other cohorts present in the CSVs (not the paper cohort)

**Ablation CSVs**, `group = legacy`:

- `legacy MAPPO (v0.4 re-scored set)`
- `legacy MAPPO (mappo_nr, June)`
- `legacy IPPO (ippo_nr, paper Table I)`
- `legacy IPPO (v0.4 re-scored set)`
- `legacy Centralized PPO (central_nr, June+Aug)`
- `legacy Centralized PPO (v0.4 re-scored set)`

These older checkpoints are evaluated with the same evaluator for provenance. They do not enter `paired_comparisons.csv`, `per_cluster_contrasts.csv` or any ablation figure; filter with `group == "primary"`.

**Calibration CSVs** hold three controller sets, identified by the boolean columns `in_S1`, `in_S2`, `in_S3` (per checkpoint) or the column `set` (summaries):

| Set | MAPPO | IPPO | Centralized PPO | Also |
|---|---|---|---|---|
| S1 — manuscript checkpoints | the 8 checkpoints that reproduce the manuscript's Table I (`mappo_pool_off_seed{1,7,13,77}`, `mappo_nr_seed{23,64,99}`, `mappo_seed42_20260526T143637`) | `ippo_nr_seed*` (8) | **substitute**: `ppo_multi_site_seed{7,13,42,99}_20260517T004954` (4; the manuscript's own centralized checkpoints no longer exist) | hysteresis, always-DPDK |
| **S2 — same-code retrained set** | §3.1 (8) | §3.1 (8) | §3.1 (8) | Shared-PPO (8, supplementary), hysteresis, always-DPDK |
| S3 — v0.4 re-scored set | May-2026 runs (8) | May-2026 ensembles (8) | same 4 as S1 | hysteresis, always-DPDK |

- The `cohorts` column of `evaluation_results.csv` gives checkpoint provenance: R = same-code, T = Table-I-traceable, P = v0.4 re-scored, L = other legacy. **For the paper cohort, filter `in_S2 == True` or `set == "S2"`.**
- Checkpoints that belong to no set (cohort L) have all three flags False.

**Figures.**
- `fig1`–`fig4` (`_S2`) plot set **S2**.
- `fig5_decision_trace.pdf` plots set **S1**: MAPPO seed 1 (`mappo_pool_off_seed1`), IPPO seed 1 (`ippo_nr_seed1`) and fixed hysteresis, on cluster 0, test steps 553–744.
  - Its cluster and window were chosen by a traffic-only rule: the cluster whose median load is closest to the 81 Mbps decision threshold, and the 48 h window with the most steps in 50–600 Mbps.
  - Its worlds are pinned, LOLO-dep-f2 and LOLO-dep-f3.
  - No S2 variant of this trace exists in the source study.

### 3.4 Calibration worlds and experiments (calibration CSVs)

**Worlds** (`world` column):

- `pinned`: the deployed surrogate, the reference world.
- 10 **primary** worlds `LOSO-dep-f0..4`, `LOLO-dep-f0..4`: deployed model configuration, refit leaving out one profiling sweep (LOSO) or one group of load levels (LOLO).
- 10 **secondary** worlds `LOSO-nes-f0..4`, `LOLO-nes-f0..4`: nested model selection.

The `tier` column is `reference`, `primary` or `secondary`. `protocol` is LOSO or LOLO, and `fold` is 0–4 (−1 for pinned).

**Experiments** (`experiment` column):

- **A**, closed-policy zero-shot: the frozen policy acts on the world's observations.
- **B**, fixed-action replay: the pinned-world action trajectory is replayed and only re-scored.

`evaluation_results.csv` contains **Experiment A only**. The summary files contain both A and B.

## 4. What each value is: per-run, mean, median, or paired difference

| File | Unit of a row | Statistic |
|---|---|---|
| `ablation/all_seed_metrics.csv` | one controller run (controller × seed), `cluster = all` (fleet total) or `0`–`9` | **Per-run totals.** No averaging over seeds. Rates are fractions of cluster-steps. |
| `ablation/aggregate_metrics.csv` | controller × metric, fleet level | **Across seeds:** `mean`, `sd` (sample, ddof = 1), `median`, `min`, `max`, 95 % t-CI of the mean (`t_ci_*`), 95 % bootstrap CI of the mean (`boot_ci_*`; 10,000 resamples, seed 20260914). `n` and `seeds` list the runs used. |
| `ablation/paired_comparisons.csv` | contrast × metric | **Seed-matched paired differences A − B.** Columns: `per_seed_diff_A_minus_B` (all 8), `mean_diff`, `sd_diff`, `median_diff`, 95 % paired-bootstrap CI of the mean difference, exact two-sided sign-flip permutation p, exact two-sided Wilcoxon p, Cohen's d_z, Hedges' g_z, `n_seeds_A_better`, `relative_to_B_mean` (mean_diff / \|mean of B\|), and Holm-adjusted p over the four primary reward contrasts. `better` gives the metric's preferred direction (`higher`, `lower`, `neutral`); `n_seeds_A_better` counts seeds where A is better in that direction. |
| `ablation/per_cluster_summary.csv` | controller × cluster | **Across seeds:** `_mean`, `_std` (ddof = 1), `_median`, `_min`, `_max` of each per-cluster metric |
| `ablation/per_cluster_contrasts.csv` | contrast × cluster | **Per-cluster paired differences (reward) across the 8 seeds:** `median`, `q1`, `q3` (IQR), `mean`, `min`, `max` |
| `calibration_robustness/evaluation_results.csv` | checkpoint × world (Experiment A), `cluster = all` | **Per-run totals.** `diff_from_pinned_<metric>` = same checkpoint in that world minus the pinned world (a within-checkpoint difference, not across seeds). |
| `calibration_robustness/controller_world_summary.csv` | set × controller × world × experiment | **Across seeds:** `_mean`, `_sd` (ddof = 1), `_median`, `_min`, `_max`, plus the mean of `diff_from_pinned_*`. `n_seeds` gives the count; baselines have n = 1. |
| `calibration_robustness/rank_stability.csv` | set × experiment × world | **Rankings of seed means** (`ranking_reward`, `ranking_energy`, `ranking_qos`, `rank_*`), plus these differences: |
| | | `delta_IPPO` = **mean of seed-matched paired differences** MAPPO − IPPO, with `delta_IPPO_seeds_favour_MAPPO`, `_seed_sd`, `_seed_min`, `_seed_max`, `_median` |
| | | `delta_hyst` = mean over MAPPO seeds of (MAPPO − fixed hysteresis) |
| | | `delta_DPDK` and `delta_central` = **difference of means** (unpaired) |
| | | `*_sign_change` and `*_ratio_to_pinned` compare each world with the pinned world |
| | | `kendall_tau_b_vs_pinned` and `spearman_vs_pinned` are rank correlations of the reward ranking |
| | | Pareto columns use seed-mean (energy, QoS-violation rate) |
| | | `mean_reward__<ctrl>`, `mean_energy_wh__<ctrl>`, `mean_qosv__<ctrl>` are seed means |
| `calibration_robustness/fold_summary.csv` | set × experiment × tier × protocol × statistic | For one `rank_stability` statistic (a seed mean or a key difference): `pinned` value, `worst` / `median` / `best` across the five folds (median over folds), and each fold's value `fold0`–`fold4`. For energy and QoS, best means lowest. |
| `calibration_robustness/uncertainty_decomposition.csv` | set × controller × experiment × metric × tier | **Seed uncertainty:** `seed_sd_pinned` and `seed_range_pinned` (pinned world), `seed_sd_median_over_worlds`. **Calibration uncertainty:** median, min, max and range across worlds of the seed means. They are reported separately, never combined, and no interval is formed across folds. |
| `calibration_robustness/decision_boundary_summary.csv` | set × controller × world × experiment | **Means across seeds** of per-run shares. Columns with `region` in the name are restricted to cluster-steps with offered load in 50–600 Mbps; `action_change_vs_pinned_all` covers all steps, and `usr_share_above_*` and `*_Mbps_interval` use the stated load ranges. It includes action changes vs pinned, USR share, world-predicted unsafe share of USR steps, USR share in intervals around 100/200/400/600 Mbps, and the world's derived thresholds (`energy_breakeven_mbps`, `qos_limit_mbps`, `decision_mbps`; surrogate-derived, not measured limits). |

**Ablation contrasts** (`contrast` column):

| Contrast | A − B | Role |
|---|---|---|
| `Delta_crit` | MAPPO − Shared-PPO | effect of the centralized critic |
| `Delta_share` | Shared-PPO − IPPO | sharing plus implementation differences (confounded) |
| `G` | MAPPO − IPPO | total |
| `MAPPO vs centralized PPO` | MAPPO − Centralized PPO | |
| `Shared-PPO vs centralized PPO` | Shared-PPO − Centralized PPO | exploratory |

## 5. Metric definitions

**Common protocol.**
- Held-out test slice: 1,009 steps of 15 min (10.51 days) × 10 clusters.
- Deterministic (argmax) actions, environment `reset(seed=42)`, forecast horizon 1 step.
- Every metric below is summed or averaged over **all 10 clusters and all 1,009 steps** unless the row is per cluster.
- Rates in CSVs are **fractions (0–1)**; figures show them in %.

### Reward (scalarized; `reward`)

The per cluster-step reward is

r = −( α·SEC + λ_qos·max(0, τ − Q) + λ_sw·E_sw + C_cd )

with α = 100, λ_qos = 30, τ = 0.9 and λ_sw = 4 (`configs/scenario_rl.yaml`):

- **SEC** = steady-state power of the serving UPF (W) / offered load (Mbps).
- **Q** = min(delay score, loss score), where score = max(0, 1 − excess / budget). The delay budget is 200 µs; the loss budget is 5 packets per interval.
- **E_sw** = switching energy (Wh) charged on a realised UPF change: 0.009476 Wh when switching to DPDK, 5.15·10⁻⁶ Wh to USR (twin v0.4.0).
- **C_cd** = cooldown cost on a realised change inside the 4-step dwell window: 0.5 × (steps remaining in the window) / 4.

**Reported value.** `reward` is the **unweighted sum of r over all clusters and steps**. It is negative, and higher is better. Centralized PPO is trained on a load-weighted version but evaluated on the same unweighted sum.

**Components.** The four terms are the non-negative costs whose sum is −reward:
- ablation: `cost_energy_term`, `cost_qos_penalty`, `cost_switch_penalty`, `cost_cooldown_penalty`;
- calibration: `energy_penalty`, `qos_penalty`, `switch_penalty`, `cooldown_penalty`.

### Energy (`energy_wh`, Wh)

- Σ power × 0.25 h over clusters and steps.
- Power is the surrogate's process-attributed steady-state power of the serving UPF. On a switching step it is time-weighted between the old and new UPF (sub-step accounting), plus the switching energy spread over that step.
- `energy_wh_steady` (calibration CSVs) excludes the switching energy.
- `switching_energy_wh` (ablation) is the switching energy alone.

### QoS violation (`qos_violation_rate`)

- The fraction of cluster-steps where the twin's `is_safe` flag is False: predicted packet loss > 5 packets per interval **or** predicted delay > 200 µs.
- On a switching step the step counts as unsafe if either the old or the new UPF is unsafe.
- **Related rates.**
  - `qscore_below_tau_rate`: fraction with Q < 0.9, the reward's QoS target.
  - `delay_violation_rate` and `loss_violation_rate` (calibration only): each budget separately.
- **Severity columns** (calibration only).
  - `severity_mean` and `severity_max`: relative budget excess max(delay excess / 200 µs, loss excess / 5), over violating steps.
  - `q_shortfall_mean`: mean of 1 − Q over violating steps.

### Switching rate (`switches_per_cluster_day`)

- (number of consecutive-step changes of the selected UPF, summed over clusters) / 10 clusters / 10.51 days.
- `switches` is the total count.
- With the sub-step accounting used, requested and realised changes are identical. The change from the initial DPDK state at the first step is not counted as a switch, although its switching cost is included in the reward.

### Other

`usr_share` is the fraction of cluster-steps served by the user-space (OAI) UPF; DPDK is the alternative.

## 6. Caveats for use in the paper

- **Ablation.** `paired_comparisons.csv` uses the same-code cohort only. p-values are exact two-sided tests with n = 8 seeds; the smallest attainable permutation p is 0.0078.
- **Calibration cohort.** Take paper values from set S2. S1 corresponds to the manuscript's original checkpoints; its centralized-PPO entries are a substitute because the original checkpoints are unavailable.
- **Degenerate secondary worlds.** In the calibration study, the secondary worlds LOLO-nes-f2 and f3 derive a USR QoS limit of 0 Mbps. Their values are extreme and appear in the CSVs and as off-axis markers in the figures.
- **Scope.** The results show robustness across alternative calibrations derived from the existing profiling data. They are not live, physical or deployed-network validation.
